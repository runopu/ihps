﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace i_HPS
{
    public partial class Registration : MetroForm
    {
        SqlConnection con = new SqlConnection("Data Source=IT68;Initial Catalog=iHPS;Integrated Security=True");
        public Registration()
        {
            InitializeComponent();
        }

        private void Registration_Load(object sender, EventArgs e)
        {
            if (txtUserName.Text == "")
            {
                grpBoxInfo.Hide();
            }

        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from login where Username='" + txtUserName.Text + "'", con);
            DataTable dt = new System.Data.DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                lblInfo.Text = "Already Taken. Please choose another name.";
                lblInfo.Show();
                grpBoxInfo.Hide();
            }
            else
            {
                lblInfo.Text = "Please enter login user information.";
                lblInfo.Show();
                grpBoxInfo.Show();
            }
        }

        private void txtConfirmPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtPassword.Text != txtConfirmPassword.Text && txtPassword.Text == "")
            {
                lblNotMatch.Text = "Password not match.";
                lblNotMatch.Show();
            }
            else
            {
                lblNotMatch.Hide();
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string qry;
            qry = "INSERT INTO login VALUES ('" + txtUserName.Text + "','" + txtPassword.Text + "','" + comboRole.Text.ToString() + "','" + txtFirstName.Text + "','" + txtLastName.Text + "')";
            SqlCommand cmd = new SqlCommand(qry, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Information Data Saved Successfully.");
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtUserName.Text = "";
            comboRole.Text = "";
            txtConfirmPassword.Text = "";
            txtPassword.Text = "";

        }
    }
}
